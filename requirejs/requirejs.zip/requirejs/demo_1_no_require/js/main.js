document.getElementById('greet').onclick = function() {
  Greeter.greetSrc = 'img/bad_greet.jpg';
  Greeter.greet();
};